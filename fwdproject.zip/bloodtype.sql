-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2017 at 03:56 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jc468471_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `Blood_type`
--

CREATE TABLE `Blood_type` (
  `Bloodgroup` varchar(20) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Availability` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `Blood_type` (`Bloodgroup`, `description`, `Availability`) VALUES
('AB+', 'AB Positive is the rarest blood type. AB plasma can be given to any patient regardless of their blood type.', 'Yes'),
('AB-', 'AB Negative is the rarest blood type. AB- can be given to only AB+ and AB-.', 'Yes'),
('A+', 'A Positive is the second most common blood type. A+ can be given to only A+ and AB+.', 'Yes'),
('A-', 'Only six percent of the population has A Negative blood. A- can be given to only A+, A-, AB+ and AB-', 'No'),
('B+', 'B Positive is the third most common occurring blood type. Approximately 8.5% of the population has B+ blood group. B+ can be given to only B+ and AB+.', 'No'),
('B-', 'B Negative blood is rare, it is important to maintain sufficient supplies for our community and local patients. Approximately 1.5% of the population has this blood group. B- can be given to only B+, B-, AB+ and AB-.', 'Yes'),
('O+', 'O Positive is the most common blood type and therefore needed by so many patients. 1 in 3 people have O+ blood (approximately 37.4% of the population). O+ can be given to only O+, A+, B+ and AB+.', 'Yes'),
('O-', 'O Negative Blood type can be given to any blood group but it only receives the O-.', 'Yes');

