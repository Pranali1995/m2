<?php include_once('config.php'); ?>
<!DOCTYPE html>
<html>
<head>
<title>Staffmembers</title>
</head>
<body>
<?php
//make the database connection
$conn  = db_connect();

//create and execute a query
$sql = "SELECT * FROM Staffmembers;";
$result = $conn -> query($sql);

print "<table border = 1>\n";

//get field names
print "<tr>\n";
while ($field = $result -> fetch_field())
{
  print "<th>" . strtoupper($field->name) . "</th>\n";
} // end while
print "</tr>\n\n";

//get row data as an associative array
while ($row = $result -> fetch_assoc()){
  print "<tr>\n";
  //look at each field
  foreach ($row as $col=>$val){
    print "  <td>$val</td>\n";
  } // end foreach
  print "</tr>\n\n";
}// end while

print "</table>\n";
$conn -> close();
?>
</body>
</html>


