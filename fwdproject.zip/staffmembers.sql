

CREATE TABLE `Staffmembers` (
  `Name` varchar(30) NOT NULL,
  `Contact No.` int(30) NOT NULL,
  `Email Id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `Staffmembers` (`Name`, `Contact No.`, `Email Id`) VALUES
('Manish Shakya', '0450969609', 'infostdmanish@gmail.com'),
('Akshay', '0415541995', 'akshaysahnan@gmail.com'),
('Bhumi', '0449596710', 'bhumipatel@gmail.com'),
('Deep', '0432732836', 'deepchahal013@gmail.com');

